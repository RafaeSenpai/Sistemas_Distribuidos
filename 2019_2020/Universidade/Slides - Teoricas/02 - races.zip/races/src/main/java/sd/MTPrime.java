package sd;

public class MTPrime extends Thread {

    // apenas 1 para todos os threads
    private static Counter c = new Counter();

    // 1 para cada thread
    private long n = 0;

    public void run() {

        while(c.getAndIncrement()<10000000) {
            // faz de conta que testa se é primo... :)

            n++;
        }
    }

    public static void main(String[] args) throws Exception {

        MTPrime[] t = new MTPrime[2];

        for(int i=0;i<t.length;i++)
            t[i] = new MTPrime();
        for(int i=0;i<t.length;i++)
            t[i].start();

        // O trabalho acontece aqui!

        for(int i=0;i<t.length;i++)
            t[i].join();

        long total = 0;
        for(int i=0;i<t.length;i++)
            total = total + t[i].n;

        System.out.println("senhas: "+total);
    }
}
