package sd;

public class SynchCounter {
    private long value;
    private boolean busy = false;

    public synchronized long getAndIncrement() {
        long temp = value;
        value = value + 1;
        return temp;

    }
}
