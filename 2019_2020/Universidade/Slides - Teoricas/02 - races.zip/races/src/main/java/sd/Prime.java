package sd;

public class Prime {
    public static void main(String[] args) throws Exception {
        Counter c = new Counter();

        long n = 0;

        while(c.getAndIncrement()<10000000) {
            // faz de conta que testa se é primo... :)

            n++;
        }

        System.out.println("senhas: "+n);
    }
}
