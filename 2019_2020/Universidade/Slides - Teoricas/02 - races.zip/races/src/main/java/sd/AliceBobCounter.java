package sd;

public class AliceBobCounter {
    private long value;

    private boolean flagAlice, flagBob;

    public long getAndIncrementAlice() {
        flagAlice = true;
        while(flagBob)
            ;

        long temp = value;
        value = value + 1;

        flagAlice = false;

        return temp;
    }

    public long getAndIncrementBob() {
        flagBob = true;
        while(flagAlice) {
            flagBob = false;
            while(flagAlice)
                ;
            flagBob = true;
        }

        long temp = value;
        value = value + 1;

        flagBob = false;

        return temp;
    }
}
