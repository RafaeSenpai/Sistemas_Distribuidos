package sd;

public class AliceBobPrime extends Thread {

    // apenas 1 para todos os threads
    private AliceBobCounter c;

    // 1 para cada thread
    private long n = 0;
    private int id;

    public AliceBobPrime(int id, AliceBobCounter c) {
        this.id = id;
        this.c = c;
    }

    public void run() {

        if (id == 0) {
            while (c.getAndIncrementAlice() < 10000000) {
                // faz de conta que testa se é primo... :)

                n++;
            }
        } else {
            while (c.getAndIncrementBob() < 10000000) {
                // faz de conta que testa se é primo... :)

                n++;
            }
        }
    }

    public static void main(String[] args) throws Exception {

        AliceBobCounter c = new AliceBobCounter();
        AliceBobPrime[] t = new AliceBobPrime[2];

        for(int i=0;i<t.length;i++)
            t[i] = new AliceBobPrime(i, c);
        for(int i=0;i<t.length;i++)
            t[i].start();

        // O trabalho acontece aqui!

        for(int i=0;i<t.length;i++)
            t[i].join();

        long total = 0;
        for(int i=0;i<t.length;i++)
            total = total + t[i].n;

        System.out.println("senhas: "+total);
    }
}
