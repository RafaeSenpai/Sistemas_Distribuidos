package sd;

public class Counter {
    private long value;
    private boolean busy = false;

    public long getAndIncrement() {
        long temp = value;
        value = value + 1;
        return temp;

    }
}
