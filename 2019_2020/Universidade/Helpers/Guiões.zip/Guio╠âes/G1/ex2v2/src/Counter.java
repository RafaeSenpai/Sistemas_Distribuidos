public class Counter {
    public int counter;

    public Counter(int c){
        this.counter = c;
    }
}
